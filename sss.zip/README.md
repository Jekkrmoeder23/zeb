# ![Logo](static/img/icon_48.png) Smarter Smartschool 

Adds a point total to Smartschool.

### [Download for Chrome here](https://chrome.google.com/webstore/detail/smarter-smartschool/lbpdknjafmmnemenflppkofaakldbfom)
